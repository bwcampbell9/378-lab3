<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="Spaceship_Tileset_big" tilewidth="64" tileheight="64" tilecount="625" columns="25">
 <image source="Subway_tiles_big.png" width="1600" height="1600"/>
 <tile id="377">
  <properties>
   <property name="name" value="box"/>
   <property name="texture" value="box"/>
   <property name="type" value="physics"/>
  </properties>
 </tile>
 <tile id="401">
  <properties>
   <property name="type" value="player"/>
  </properties>
 </tile>
</tileset>
