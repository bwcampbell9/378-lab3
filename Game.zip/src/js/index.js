import TileMapLevel from "./tileMapLoader.js"
import Phaser from "../lib/phaser.js"
import EndLevel from "./win_scene.js"

const config = {
    type: Phaser.AUTO,
    width: 400,
    height: 200,
    parent: "game-container",
    pixelArt: true,
    backgroundColor: "#1d212d",
    scene: [TileMapLevel, EndLevel],
    physics: {
      default: "arcade",
      arcade: {
        gravity: { y: 1000 }
      }
    },
    scale: {
      mode: Phaser.Scale.FIT,
      autoCenter: Phaser.Scale.CENTER_BOTH
    }
  };

const game = new Phaser.Game(config);

  